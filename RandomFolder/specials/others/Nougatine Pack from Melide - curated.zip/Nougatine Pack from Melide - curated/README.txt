HELLO

While I have a French community, this file will be written in English so that it can be understood by anyone in the world reading this file.

YOU MAY NOT:

- Sell this pack unless you are the author.
- Sell individual unmodified files from this pack; modifications must be different enough from the originals.
- Give this pack to someone else without including this README file.
- Give this pack to someone else, claiming it's your own.
- Give this pack to someone else with samples that were not in the original folder.

YOU MAY:

- Modify any files from this pack as you please.
- Use any files from this pack in your productions/creations and sell them.
- Create new samples using files from this pack and sell them.

Thank you so much for downloading this pack, and I wish you productive sessions!